@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0clinic.ps1" backup
pause
